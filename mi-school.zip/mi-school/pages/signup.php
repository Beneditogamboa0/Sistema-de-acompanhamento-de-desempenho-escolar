<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../public/styles/register.css">
    <title>Signup</title>
</head>
<body>
    <form onsubmit="return signUp()">
        <span>Criar Conta</span>
        <input id="ifirstName" type="Text" placeholder="Primeiro nome">
        <input id="ilastName" type="Text" placeholder="Último nome">
        <input id="iemail" type="email" placeholder="Email">
        <input id="ipassword" type="password" placeholder="Insira sua senha">
        <input id="ipasswordCheck" type="password" placeholder="Confirme sua senha">
        <label for="iuserType">Escolha o tipo de usuário</label>
        <select id="iuserType">
            <option value="1">Professor</option>
            <option value="2">Aluno</option>
        </select>
        <button type="submit">Criar conta</button>
        <span>Já tem uma conta? <a href="login.php">Faça login</a></span>
    </form>
</body>
</html>
<script>
    async function signUp(){
        event.preventDefault()
        const user={
            name:ifirstName.value+" "+ilastName.value,
            email:iemail.value,
            password:ipassword.value,
            userType:iuserType.value
        }
        ans=await fetch("./../routes/userSignUp.php",{
            method:"post",
            body:JSON.stringify(user),
            header:{"content-type":"application/json"}
        })
        ans=await ans.json()
        console.log(ans)
    }
</script>