<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../public/styles/register.css">
    <title>Login</title>
</head>
<body>
    <form onsubmit="return login()">
        <span>Login</span>
        <input id="iemail" type="email" placeholder="Email">
        <input id="ipassword" type="password" placeholder="Senha">
        <button type="submit">Entrar</button>
        <span>Não tem conta ainda? <a href="signup.php">Crie uma conta.</a></span>
    </form>
</body>
</html>
<script>
    async function login(){
        event.preventDefault()
        const user={
            email:iemail.value,
            password:ipassword.value
        }
        ans=await fetch("./../routes/userLogin.php",{
            method:"post",
            body:JSON.stringify(user),
            header:{"content-type":"application/json"}
        })
        ans=await ans.json()
        console.log(ans)
    }
</script>