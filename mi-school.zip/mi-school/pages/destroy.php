<?php
    session_start();
    $logout=file_get_contents("php://input");
    if(isset($_SESSION["type"]) && $logout){
        session_destroy();
        echo json_encode(["redirect"=>"./login.php"]);
    }