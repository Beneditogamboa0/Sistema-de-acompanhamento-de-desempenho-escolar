<li><a href="#">Principal</a></li>
<li><a href="#">Alunos</a></li>
<li><a href="#">Professores</a></li>
<li><a href="#">Cursos</a></li>
<li><a href="#">Classes</a></li>