<link rel="stylesheet" href="../components/student-informations/student-informations.css">
<div class="student-informations">
    <span>Minhas Informações <i class="fa fa-newspaper"></i></span>
    <div class="information">
        <span>Nome: Migos</span>
        <span>BI: 00495726LA923</span>
        <span>Data de nascimento: 20/12/2077</span>
        <span>Classe: 13ª</span>
        <span>Turma: TI13A</span>
        <span>Curso: Informática</span>
        <span>Nome do Encarregado: Quavo</span>
        <span>Contacto do Encarregado: 934758012 / quavolikehuncho@gmail.com</span>
    </div>
</div>