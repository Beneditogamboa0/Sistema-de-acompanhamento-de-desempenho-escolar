<link rel="stylesheet" href="../components/main-container/main-container.css">
<main id="main-container">
    <?php
    $userType=$_SESSION["type"];
    switch($userType){
        case "Aluno":
            include_once "../components/student-main/student-main.php";
            break;
        case "Admin":
            include_once "../components/admin-main/admin-main.php";
            break;
        case "Professor":
            include_once "../components/teacher-main/teacher-main.php";
            break;
    }
    ?>
</main>