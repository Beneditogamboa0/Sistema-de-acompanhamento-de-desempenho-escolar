<link rel="stylesheet" href="../components/main-container/main-container.css">
<main>
    <?php include_once "../components/student-subjects/student-subjects.php"?>
</main>