<link rel="stylesheet" href="../components/student-presence/student-presence.css">
<div class="student-presence">
    <div class="presence">
        <span>Disciplina</span>
        <div class="presence-info">
            <div>
                <span>Total de x</span>
                txt
            </div>
            <div>
                <span>Total de x</span>
                txt
            </div>
            <div>
                <span>Total de x</span>
                txt
            </div>
        </div>
    </div>
    <div class="presence">
        <span>Disciplina</span>
        <div class="presence-info">
            <div>
                <span>Total de x</span>
                txt
            </div>
            <div>
                <span>Total de x</span>
                txt
            </div>
            <div>
                <span>Total de x</span>
                txt
            </div>
        </div>
    </div>
</div>