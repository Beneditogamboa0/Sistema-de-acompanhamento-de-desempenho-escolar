<link rel="stylesheet" href="../components/student-main/student-main.css">
<div class="student-main">
    <div class="student-main-dashboard">
        <div style="grid-area: s1">
            <span>Disciplina com melhor média</span>
            Matemática
        </div>
        <div style="grid-area: s2">
            <span>Média Geral</span>
            17 Valores
        </div>
        <div style="grid-area: s3">
            <span>Precisa rever</span>
            Física
        </div>
        <div style="grid-area: s4">
            <span>Avaliação comportamental</span>
            Boa
        </div>
    </div>
</div>