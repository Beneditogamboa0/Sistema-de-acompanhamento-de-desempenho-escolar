<li><a href="#">Principal</a></li>
<li><a href="#">Informações pessoais</a></li>
<li><a href="#">Notas</a></li>
<li><a href="#">Presenças</a></li>
<li><a href="#">Disciplinas</a></li>