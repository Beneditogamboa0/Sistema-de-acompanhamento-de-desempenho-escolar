<link rel="stylesheet" href="../components/student-marks/student-marks.css">
<div class="student-marks">
    <div class="subject">
        <span>Disciplina</span>
        <div class="subject-mark">
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
        </div>
    </div>
    <div class="subject">
        <span>Disciplina</span>
        <div class="subject-mark">
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
            <div>
                <span>Prova</span>
                17v
            </div>
        </div>
    </div>
</div>