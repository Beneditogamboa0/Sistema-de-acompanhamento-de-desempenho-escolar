<link rel="stylesheet" href="../components/modal/modal.css">
<div class="modal">
    <div class="modal-area"></div>
</div>