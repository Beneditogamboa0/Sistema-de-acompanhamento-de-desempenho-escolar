<link rel="stylesheet" href="../components/admin-teacher/admin-teacher.css">
<div class="admin-teacher">
    <div class="admin-filter-options">
        <label for="filters1">Filtrar por:</label>
        <select name="" id="filters1">
            <option value="1">Classe</option>
            <option value="2">Turma</option>
            <option value="3">Curso</option>
        </select>
        <select name="" id="filters2">
            <option value="1">10ª</option>
            <option value="2">11ª</option>
            <option value="3">12ª</option>
            <option value="4">13ª</option>
            <!--options dinâmicos aqui-->
        </select>
        <select name="" id="filters3">
            <option value="1">TI</option>
            <option value=2">DP</option>
        </select>
    </div>
    <div class="admin-teacher-list">
        <div class="teacher">
            <span>Nome: Quavo Huncho</span>
            <span>Classe(s): 12ª,13ª</span>
            <span>Curso(s): TI,DP</span>
            <span>Turma(s): TI13A,DP13A</span>
            <div class="teacher-action">
                <button>Informações</button>
                <button>Notas</button>
                <button>Presenças</button>
            </div>
        </div>
        <div class="teacher">
            <span>Nome: Kendrick Lamar</span>
            <span>Classe(s): 12ª,13ª</span>
            <span>Curso(s): TI,DP</span>
            <span>Turma(s): TI13A,DP13A</span>
            <div class="teacher-action">
                <button>Informações</button>
                <button>Notas</button>
                <button>Presenças</button>
            </div>
        </div>
    </div>
</div>