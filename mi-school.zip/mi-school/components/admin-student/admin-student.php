<link rel="stylesheet" href="../components/admin-student/admin-student.css">
<div class="admin-student">
    <div class="admin-filter-options">
        <label for="filters1">Filtrar por:</label>
        <select name="" id="filters1">
            <option value="1">Classe</option>
            <option value="2">Turma</option>
            <option value="3">Curso</option>
        </select>
        <select name="" id="filters2">
            <option value="1">10ª</option>
            <option value="2">11ª</option>
            <option value="3">12ª</option>
            <option value="4">13ª</option>
            <!--options dinâmicos aqui-->
        </select>
        <select name="" id="filters3">
            <option value="1">TI</option>
            <option value=2">DP</option>
        </select>
    </div>
    <div class="admin-student-list">
        <div class="student">
            <span>Nome: Benedito Gambôa</span>
            <span>Classe: 13ª</span>
            <span>Curso: TI</span>
            <span>Turma: TI13A</span>
            <div class="student-action">
                <button>Informações</button>
                <button>Notas</button>
                <button>Presenças</button>
            </div>
        </div>
        <div class="student">
            <span>Nome: Benedito Gambôa</span>
            <span>Classe: 13ª</span>
            <span>Curso: TI</span>
            <span>Turma: TI13A</span>
            <div class="student-action">
                <button>Informações</button>
                <button>Notas</button>
                <button>Presenças</button>
            </div>
        </div>
    </div>
</div>