<link rel="stylesheet" href="../components/sidebar/sidebar.css">
<nav>
    <span class="logo">Mi-School <i class="fa fa-pencil"></i></span>
    <ul>
        <?php include_once __DIR__."/../student-links/student-links.php"?>
    </ul>
    <footer><img src="../public/images/default-pfp.jpg" alt=""><span>Benedito Gambôa</span></footer>
</nav>