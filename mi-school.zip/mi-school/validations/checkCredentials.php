<?php
    function checkEmail($email)
{
  $email = filter_var($email, FILTER_SANITIZE_EMAIL);
  $email_length = strlen($email);
  $max_length = 200;

  if (!filter_var($email, FILTER_VALIDATE_EMAIL))
    return false;

  if ($email_length > $max_length)
    return false;

  return true;
}

function checkPassword($password)
{
  $password = trim($password);
  $password = filter_var($password, FILTER_SANITIZE_EMAIL);
  $min_length = 8;
  $max_length = 30;
  $pass_length = strlen($password);

  if ($pass_length < $min_length || $pass_length > $max_length)
    return false;

  if (str_contains($password, " "))
    return false;

  return true;
}

//função de verificação principal para login:
function checkCredentials($email, $password)
{
  return checkPassword($password) && checkEmail($email) ?
    ["status" => true, "msg" => "Credenciais verificadas com sucesso"] :
    ["status" => false, "msg" => "Verifique as suas credenciais"];
}