function userNameLength() {
    if (username.innerText.length > 12)
        username.innerText = username.innerText.slice(0, 11) + "..."
}
userNameLength()

function loadUserOptions(){
    userOptions=document.querySelector(".user-options")
    userOptions.classList.toggle("on")
}
userPfp=document.getElementById("user-pfp")
userPfp.addEventListener("click",loadUserOptions)

async function logout(){
    ans=await fetch("./destroy.php",{
        method:"post",
        body: true
    })
    ans=await ans.json()
    window.location.href=ans.redirect
}
logoutBtn=document.querySelector(".user-option-btn")
logoutBtn.addEventListener("click",logout)