<?php
include_once __DIR__ . ("/../model/user-model.php");
include_once __DIR__ . ("/../validations/checkCredentials.php");
include_once __DIR__ . ("/../sessions/startSession.php");
$user = json_decode(file_get_contents("php://input"), true);
function signUp()
{
    global $user;
    $userObj = new User($user["email"], $user["password"], $user["name"], $user["userType"]);
    $check=checkCredentials($user["email"],$user["password"]);
    if(!$check["status"]){
        echo json_encode($check);
        die();
    }
    echo json_encode($userObj->signUp());
}
function login(){
    global $user;
    $check=checkCredentials($user["email"],$user["password"]);
    if(!$check["status"]){
        echo json_encode($check);
        die();
    }
    $login=User::login($user["email"],$user["password"]);
    if(!$login["status"]){
        echo json_encode($login);
        die();
    }
    setUserInfo($login["user"]["id"],$login["user"]["nome"],$login["user"]["tipo_usuario"]);
    echo json_encode($login);
    die();
}