<?php
include_once __DIR__ . ("/../model/user-model.php");
include_once __DIR__ . ("/../validations/checkCredentials.php");
$user = json_decode(file_get_contents("php://input"), true);
function signUp()
{
    global $user;
    $userObj = new User($user["email"], $user["password"], $user["name"], $user["userType"]);
    $check=checkCredentials($user["email"],$user["password"]);
    if(!$check["status"]){
        echo json_encode($check);
        die();
    }
    echo $userObj->signUp();
}
function login(){
    global $user;
    $check=checkCredentials($user["email"],$user["password"]);
    if(!$check["status"]){
        echo json_encode($check);
        die();
    }
    echo User::login($user["email"],$user["password"]);
    die();
}