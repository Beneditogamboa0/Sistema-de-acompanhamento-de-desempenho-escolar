<?php
    function setUserInfo($id,$name,$type){
        session_start();
        $_SESSION["id"]=$id;
        $_SESSION["name"]=$name;
        $_SESSION["type"]=$type;
    }