-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Jan-2026 às 01:12
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `scholamea`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nome` varchar(10) NOT NULL DEFAULT 'admin',
  `nif` varchar(14) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo_usuario` varchar(10) NOT NULL DEFAULT 'Admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `admin`
--

INSERT INTO `admin` (`id`, `nome`, `nif`, `senha`, `tipo_usuario`) VALUES
(1, 'admin', '0078433599', 'adminadmin', 'Admin'),
(2, 'superadmin', '1234567890', 'superadmin123', 'Admin');

-- --------------------------------------------------------

--
-- Estrutura da tabela `alunos`
--

CREATE TABLE `alunos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `data_nascimento` date NOT NULL,
  `bi` varchar(15) NOT NULL,
  `id_classe` int(11) NOT NULL,
  `id_curso` int(11) DEFAULT NULL,
  `id_encarregado` int(11) DEFAULT NULL,
  `id_turma` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `alunos`
--

INSERT INTO `alunos` (`id`, `nome`, `data_nascimento`, `bi`, `id_classe`, `id_curso`, `id_encarregado`, `id_turma`) VALUES
(34, 'Benedito', '2007-03-31', '008433599LA044', 1, 1, 15, 7),
(36, 'Aomine Daiki', '2007-08-17', '008433599LA043', 1, 2, 17, 10),
(37, 'Benedito Gambôa', '2007-03-31', '008363325LA044', 3, 1, 18, 9),
(38, 'Quavo Huncho', '2005-04-04', '000000000LA000', 2, 3, 19, 14),
(39, 'Leonny', '2001-07-21', '008363324LA033', 1, 2, 20, 10),
(40, 'Akashi', '2004-03-31', '949494949LA000', 1, 1, 21, 7),
(41, 'Lucas Ferreira', '2006-05-10', '111222333LA001', 2, 1, 22, 8),
(42, 'Rita Fonseca', '2007-11-02', '222333444LA002', 3, 1, 23, 9),
(43, 'Samuel Costa', '2005-01-20', '333444555LA003', 1, 2, 24, 10),
(44, 'Inês Rocha', '2006-07-15', '444555666LA004', 2, 3, 22, 14);

-- --------------------------------------------------------

--
-- Estrutura da tabela `aluno_avaliacao`
--

CREATE TABLE `aluno_avaliacao` (
  `id` int(11) NOT NULL,
  `id_aluno` int(11) NOT NULL,
  `id_avaliacao` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `aluno_avaliacao`
--

INSERT INTO `aluno_avaliacao` (`id`, `id_aluno`, `id_avaliacao`) VALUES
(10, 34, 8),
(12, 34, 10),
(13, 34, 11),
(14, 34, 12),
(15, 41, 13),
(16, 41, 14);

-- --------------------------------------------------------

--
-- Estrutura da tabela `avaliacao`
--

CREATE TABLE `avaliacao` (
  `id` int(11) NOT NULL,
  `id_nota` int(11) NOT NULL,
  `id_disciplina` int(11) NOT NULL,
  `id_tipo_teste` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `avaliacao`
--

INSERT INTO `avaliacao` (`id`, `id_nota`, `id_disciplina`, `id_tipo_teste`) VALUES
(8, 19, 1, 1),
(10, 1, 2, 1),
(11, 1, 4, 1),
(12, 1, 1, 2),
(13, 10, 1, 1),
(14, 11, 2, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `numero` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `classes`
--

INSERT INTO `classes` (`id`, `numero`) VALUES
(1, 10),
(2, 11),
(3, 12);

-- --------------------------------------------------------

--
-- Estrutura da tabela `contacto_encarregado`
--

CREATE TABLE `contacto_encarregado` (
  `id` int(11) NOT NULL,
  `id_encarregado` int(11) NOT NULL,
  `telefone` int(11) NOT NULL,
  `telefone_secundario` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `contacto_encarregado`
--

INSERT INTO `contacto_encarregado` (`id`, `id_encarregado`, `telefone`, `telefone_secundario`, `email`) VALUES
(10, 15, 923554706, 953491803, 'antonia@gmail.com'),
(11, 17, 923554706, 953491803, 'akashi@gmail.com'),
(12, 18, 923554706, 928783247, 'antoniagamboa@gmail.com'),
(13, 19, 987654321, 923456789, 'migos@gmail.com'),
(14, 20, 935555500, 945555500, 'benneo@gmail.com'),
(15, 21, 922333444, 911555666, 'kiseki@gmail.com'),
(16, 22, 912345678, 923456789, 'maria.lopes@email.com'),
(17, 23, 934567890, 945678901, 'jose.manuel@email.com'),
(18, 24, 956789012, 967890123, 'ana.paula@email.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursos`
--

CREATE TABLE `cursos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `cursos`
--

INSERT INTO `cursos` (`id`, `nome`) VALUES
(1, 'Técnico de Informática (TI)'),
(2, 'Desenho Projetista (DP)'),
(3, 'Bioquímica (BQ)');

-- --------------------------------------------------------

--
-- Estrutura da tabela `dias_aula`
--

CREATE TABLE `dias_aula` (
  `id` int(11) NOT NULL,
  `dia` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `dias_aula`
--

INSERT INTO `dias_aula` (`id`, `dia`) VALUES
(1, 'Segunda'),
(2, 'Terça'),
(3, 'Quarta'),
(4, 'Quinta'),
(5, 'Sexta');

-- --------------------------------------------------------

--
-- Estrutura da tabela `dias_disciplina`
--

CREATE TABLE `dias_disciplina` (
  `id_disciplina` int(11) NOT NULL,
  `id_dia_aula` int(11) DEFAULT NULL,
  `id_turma` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `dias_disciplina`
--

INSERT INTO `dias_disciplina` (`id_disciplina`, `id_dia_aula`, `id_turma`) VALUES
(1, 1, 7),
(1, 3, 7),
(2, 2, 7),
(4, 4, 7),
(1, 1, 8),
(2, 3, 8),
(4, 5, 8),
(1, 2, 9),
(2, 4, 9),
(4, 1, 9),
(1, 1, 10),
(5, 3, 10),
(1, 2, 14),
(3, 4, 14),
(6, 5, 14);

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplinas`
--

CREATE TABLE `disciplinas` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `disciplinas`
--

INSERT INTO `disciplinas` (`id`, `nome`) VALUES
(1, 'Matemática'),
(2, 'Física'),
(3, 'Química'),
(4, 'Técnicas e Linguagens de Programação'),
(5, 'Geometria Descritiva'),
(6, 'Biologia Celular');

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina_classe`
--

CREATE TABLE `disciplina_classe` (
  `id_classe` int(11) NOT NULL,
  `id_disciplina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `disciplina_classe`
--

INSERT INTO `disciplina_classe` (`id_classe`, `id_disciplina`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(3, 1),
(3, 2),
(3, 3),
(3, 4),
(3, 5),
(3, 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `disciplina_curso`
--

CREATE TABLE `disciplina_curso` (
  `id_disciplina` int(11) NOT NULL,
  `id_curso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `disciplina_curso`
--

INSERT INTO `disciplina_curso` (`id_disciplina`, `id_curso`) VALUES
(2, 1),
(1, 1),
(4, 1),
(1, 2),
(2, 2),
(5, 2),
(3, 3),
(1, 3),
(6, 3),
(2, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `encarregados`
--

CREATE TABLE `encarregados` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `bi` char(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `encarregados`
--

INSERT INTO `encarregados` (`id`, `nome`, `bi`) VALUES
(15, 'Antónia', '001234567LA000'),
(17, 'Akashi Seijuro', '001234567LA001'),
(18, 'Antónia Gambôa', '009876543LA029'),
(19, 'Migos', '111111111LA111'),
(20, 'Benneo', '746583290LA111'),
(21, 'Kiseki', '646464646LA777'),
(22, 'Maria Lopes', '888777666LA111'),
(23, 'José Manuel', '999888777LA222'),
(24, 'Ana Paula', '555444333LA333');

-- --------------------------------------------------------

--
-- Estrutura da tabela `notas`
--

CREATE TABLE `notas` (
  `id` int(11) NOT NULL,
  `nota` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `notas`
--

INSERT INTO `notas` (`id`, `nota`) VALUES
(1, 0),
(2, 1),
(3, 2),
(4, 3),
(5, 4),
(6, 5),
(7, 6),
(8, 7),
(9, 8),
(10, 9),
(11, 10),
(12, 11),
(13, 12),
(14, 13),
(15, 14),
(16, 15),
(17, 16),
(18, 17),
(19, 18),
(20, 19),
(21, 20);

-- --------------------------------------------------------

--
-- Estrutura da tabela `presencas`
--

CREATE TABLE `presencas` (
  `id` int(11) NOT NULL,
  `estado` tinyint(1) DEFAULT 0,
  `id_disciplina` int(11) NOT NULL,
  `data` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `presencas`
--

INSERT INTO `presencas` (`id`, `estado`, `id_disciplina`, `data`) VALUES
(17, 0, 2, '2026-01-19'),
(18, 0, 2, '2026-01-18'),
(19, 0, 2, '2026-01-24'),
(20, 0, 2, '2026-01-25'),
(21, 0, 2, '2026-01-27'),
(22, 0, 2, '2026-01-28');

-- --------------------------------------------------------

--
-- Estrutura da tabela `presenca_aluno`
--

CREATE TABLE `presenca_aluno` (
  `id_aluno` int(11) DEFAULT NULL,
  `id_presenca` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `presenca_aluno`
--

INSERT INTO `presenca_aluno` (`id_aluno`, `id_presenca`) VALUES
(34, 17),
(34, 18),
(34, 19),
(34, 20),
(34, 21),
(34, 22);

-- --------------------------------------------------------

--
-- Estrutura da tabela `professores`
--

CREATE TABLE `professores` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `data_nascimento` date NOT NULL,
  `bi` char(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `professores`
--

INSERT INTO `professores` (`id`, `nome`, `data_nascimento`, `bi`) VALUES
(4, 'Tyrese', '2000-01-15', '001234567LA000'),
(5, 'Carlos Mendes', '1985-06-12', '123123123LA111'),
(6, 'Joana Silva', '1990-09-25', '321321321LA222'),
(7, 'Pedro António', '1982-02-18', '456456456LA333');

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor_classe`
--

CREATE TABLE `professor_classe` (
  `id_professor` int(11) NOT NULL,
  `id_classe` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `professor_classe`
--

INSERT INTO `professor_classe` (`id_professor`, `id_classe`) VALUES
(4, 1),
(5, 2),
(5, 3),
(6, 1),
(7, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor_curso`
--

CREATE TABLE `professor_curso` (
  `id_professor` int(11) NOT NULL,
  `id_curso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `professor_curso`
--

INSERT INTO `professor_curso` (`id_professor`, `id_curso`) VALUES
(4, 1),
(5, 1),
(6, 2),
(7, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor_disciplina`
--

CREATE TABLE `professor_disciplina` (
  `id_professor` int(11) NOT NULL,
  `id_disciplina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `professor_disciplina`
--

INSERT INTO `professor_disciplina` (`id_professor`, `id_disciplina`) VALUES
(4, 1),
(4, 2),
(5, 4),
(5, 1),
(6, 5),
(7, 6);

-- --------------------------------------------------------

--
-- Estrutura da tabela `professor_turma`
--

CREATE TABLE `professor_turma` (
  `id_professor` int(11) DEFAULT NULL,
  `id_turma` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `professor_turma`
--

INSERT INTO `professor_turma` (`id_professor`, `id_turma`) VALUES
(4, 7),
(5, 8),
(5, 9),
(6, 10),
(7, 14);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_teste`
--

CREATE TABLE `tipo_teste` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tipo_teste`
--

INSERT INTO `tipo_teste` (`id`, `nome`) VALUES
(1, 'Prova do Professor 1'),
(2, 'Prova Trimestral 1'),
(3, 'Prova do Professor 2'),
(4, 'Prova Trimestral 2'),
(5, 'Prova do Professor 3'),
(6, 'Prova Trimestral 3'),
(7, 'Exame');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_usuario`
--

CREATE TABLE `tipo_usuario` (
  `id` int(11) NOT NULL,
  `tipo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tipo_usuario`
--

INSERT INTO `tipo_usuario` (`id`, `tipo`) VALUES
(1, 'Professor'),
(2, 'Aluno'),
(3, 'Admin');

-- --------------------------------------------------------

--
-- Estrutura da tabela `turmas`
--

CREATE TABLE `turmas` (
  `id` int(11) NOT NULL,
  `nome` varchar(10) DEFAULT NULL,
  `id_curso` int(11) DEFAULT NULL,
  `id_classe` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `turmas`
--

INSERT INTO `turmas` (`id`, `nome`, `id_curso`, `id_classe`) VALUES
(7, 'TI10A', 1, 1),
(8, 'TI11A', 1, 2),
(9, 'TI12A', 1, 3),
(10, 'DP10A', 2, 1),
(11, 'DP11A', 2, 2),
(12, 'DP12A', 2, 3),
(13, 'BQ10A', 3, 1),
(14, 'BQ11A', 3, 2),
(15, 'BQ12A', 3, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `id_tipo_usuario` int(11) NOT NULL,
  `id_aluno` int(11) DEFAULT NULL,
  `id_professor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `senha`, `id_tipo_usuario`, `id_aluno`, `id_professor`) VALUES
(21, 'benedito', 2, 34, NULL),
(23, 'tyresehali', 1, NULL, 4),
(24, 'lucas1234', 2, 41, NULL),
(25, 'rita1234', 2, 42, NULL),
(26, 'samuel1234', 2, 43, NULL),
(27, 'ines1234', 2, 44, NULL),
(28, 'carlos1234', 1, NULL, 5),
(29, 'joana1234', 1, NULL, 6),
(30, 'pedro123', 1, NULL, 7);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nif` (`nif`);

--
-- Índices para tabela `alunos`
--
ALTER TABLE `alunos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bi` (`bi`),
  ADD KEY `id_classe` (`id_classe`),
  ADD KEY `id_curso` (`id_curso`),
  ADD KEY `id_turma` (`id_turma`),
  ADD KEY `alunos_ibfk_5` (`id_encarregado`);

--
-- Índices para tabela `aluno_avaliacao`
--
ALTER TABLE `aluno_avaliacao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_aluno` (`id_aluno`),
  ADD KEY `id_avaliacao` (`id_avaliacao`);

--
-- Índices para tabela `avaliacao`
--
ALTER TABLE `avaliacao`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_nota` (`id_nota`),
  ADD KEY `id_disciplina` (`id_disciplina`),
  ADD KEY `id_tipo_teste` (`id_tipo_teste`);

--
-- Índices para tabela `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `contacto_encarregado`
--
ALTER TABLE `contacto_encarregado`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_encarregado` (`id_encarregado`);

--
-- Índices para tabela `cursos`
--
ALTER TABLE `cursos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `dias_aula`
--
ALTER TABLE `dias_aula`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `dias_disciplina`
--
ALTER TABLE `dias_disciplina`
  ADD KEY `id_disciplina` (`id_disciplina`),
  ADD KEY `id_dia_aula` (`id_dia_aula`),
  ADD KEY `id_turma` (`id_turma`);

--
-- Índices para tabela `disciplinas`
--
ALTER TABLE `disciplinas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `disciplina_classe`
--
ALTER TABLE `disciplina_classe`
  ADD KEY `id_classe` (`id_classe`),
  ADD KEY `id_disciplina` (`id_disciplina`);

--
-- Índices para tabela `disciplina_curso`
--
ALTER TABLE `disciplina_curso`
  ADD KEY `id_curso` (`id_curso`),
  ADD KEY `id_disciplina` (`id_disciplina`);

--
-- Índices para tabela `encarregados`
--
ALTER TABLE `encarregados`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bi` (`bi`);

--
-- Índices para tabela `notas`
--
ALTER TABLE `notas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `presencas`
--
ALTER TABLE `presencas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_disciplina` (`id_disciplina`);

--
-- Índices para tabela `presenca_aluno`
--
ALTER TABLE `presenca_aluno`
  ADD KEY `id_aluno` (`id_aluno`),
  ADD KEY `id_presenca` (`id_presenca`);

--
-- Índices para tabela `professores`
--
ALTER TABLE `professores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bi` (`bi`);

--
-- Índices para tabela `professor_classe`
--
ALTER TABLE `professor_classe`
  ADD KEY `id_professor` (`id_professor`),
  ADD KEY `id_classe` (`id_classe`);

--
-- Índices para tabela `professor_curso`
--
ALTER TABLE `professor_curso`
  ADD KEY `id_professor` (`id_professor`),
  ADD KEY `id_curso` (`id_curso`);

--
-- Índices para tabela `professor_disciplina`
--
ALTER TABLE `professor_disciplina`
  ADD KEY `id_professor` (`id_professor`),
  ADD KEY `id_disciplina` (`id_disciplina`);

--
-- Índices para tabela `professor_turma`
--
ALTER TABLE `professor_turma`
  ADD KEY `id_professor` (`id_professor`),
  ADD KEY `id_turma` (`id_turma`);

--
-- Índices para tabela `tipo_teste`
--
ALTER TABLE `tipo_teste`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `turmas`
--
ALTER TABLE `turmas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_curso` (`id_curso`),
  ADD KEY `id_classe` (`id_classe`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_tipo_usuario` (`id_tipo_usuario`),
  ADD KEY `id_aluno` (`id_aluno`),
  ADD KEY `id_professor` (`id_professor`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `alunos`
--
ALTER TABLE `alunos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT de tabela `aluno_avaliacao`
--
ALTER TABLE `aluno_avaliacao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `avaliacao`
--
ALTER TABLE `avaliacao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `contacto_encarregado`
--
ALTER TABLE `contacto_encarregado`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `cursos`
--
ALTER TABLE `cursos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `dias_aula`
--
ALTER TABLE `dias_aula`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `disciplinas`
--
ALTER TABLE `disciplinas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `encarregados`
--
ALTER TABLE `encarregados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de tabela `notas`
--
ALTER TABLE `notas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de tabela `presencas`
--
ALTER TABLE `presencas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de tabela `professores`
--
ALTER TABLE `professores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `tipo_teste`
--
ALTER TABLE `tipo_teste`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `turmas`
--
ALTER TABLE `turmas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `alunos`
--
ALTER TABLE `alunos`
  ADD CONSTRAINT `alunos_ibfk_2` FOREIGN KEY (`id_classe`) REFERENCES `classes` (`id`),
  ADD CONSTRAINT `alunos_ibfk_3` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`),
  ADD CONSTRAINT `alunos_ibfk_5` FOREIGN KEY (`id_encarregado`) REFERENCES `encarregados` (`id`),
  ADD CONSTRAINT `alunos_ibfk_6` FOREIGN KEY (`id_turma`) REFERENCES `turmas` (`id`);

--
-- Limitadores para a tabela `aluno_avaliacao`
--
ALTER TABLE `aluno_avaliacao`
  ADD CONSTRAINT `aluno_avaliacao_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `aluno_avaliacao_ibfk_2` FOREIGN KEY (`id_avaliacao`) REFERENCES `avaliacao` (`id`);

--
-- Limitadores para a tabela `avaliacao`
--
ALTER TABLE `avaliacao`
  ADD CONSTRAINT `avaliacao_ibfk_1` FOREIGN KEY (`id_nota`) REFERENCES `notas` (`id`),
  ADD CONSTRAINT `avaliacao_ibfk_2` FOREIGN KEY (`id_disciplina`) REFERENCES `disciplinas` (`id`),
  ADD CONSTRAINT `avaliacao_ibfk_3` FOREIGN KEY (`id_tipo_teste`) REFERENCES `tipo_teste` (`id`);

--
-- Limitadores para a tabela `contacto_encarregado`
--
ALTER TABLE `contacto_encarregado`
  ADD CONSTRAINT `contacto_encarregado_ibfk_1` FOREIGN KEY (`id_encarregado`) REFERENCES `encarregados` (`id`);

--
-- Limitadores para a tabela `dias_disciplina`
--
ALTER TABLE `dias_disciplina`
  ADD CONSTRAINT `dias_disciplina_ibfk_1` FOREIGN KEY (`id_disciplina`) REFERENCES `disciplinas` (`id`),
  ADD CONSTRAINT `dias_disciplina_ibfk_3` FOREIGN KEY (`id_dia_aula`) REFERENCES `dias_aula` (`id`),
  ADD CONSTRAINT `dias_disciplina_ibfk_4` FOREIGN KEY (`id_turma`) REFERENCES `turmas` (`id`);

--
-- Limitadores para a tabela `disciplina_classe`
--
ALTER TABLE `disciplina_classe`
  ADD CONSTRAINT `disciplina_classe_ibfk_1` FOREIGN KEY (`id_classe`) REFERENCES `classes` (`id`),
  ADD CONSTRAINT `disciplina_classe_ibfk_2` FOREIGN KEY (`id_disciplina`) REFERENCES `disciplinas` (`id`);

--
-- Limitadores para a tabela `disciplina_curso`
--
ALTER TABLE `disciplina_curso`
  ADD CONSTRAINT `disciplina_curso_ibfk_1` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`),
  ADD CONSTRAINT `disciplina_curso_ibfk_2` FOREIGN KEY (`id_disciplina`) REFERENCES `disciplinas` (`id`);

--
-- Limitadores para a tabela `presencas`
--
ALTER TABLE `presencas`
  ADD CONSTRAINT `presencas_ibfk_1` FOREIGN KEY (`id_disciplina`) REFERENCES `disciplinas` (`id`);

--
-- Limitadores para a tabela `presenca_aluno`
--
ALTER TABLE `presenca_aluno`
  ADD CONSTRAINT `presenca_aluno_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `presenca_aluno_ibfk_2` FOREIGN KEY (`id_presenca`) REFERENCES `presencas` (`id`);

--
-- Limitadores para a tabela `professor_classe`
--
ALTER TABLE `professor_classe`
  ADD CONSTRAINT `professor_classe_ibfk_1` FOREIGN KEY (`id_professor`) REFERENCES `professores` (`id`),
  ADD CONSTRAINT `professor_classe_ibfk_2` FOREIGN KEY (`id_classe`) REFERENCES `classes` (`id`);

--
-- Limitadores para a tabela `professor_curso`
--
ALTER TABLE `professor_curso`
  ADD CONSTRAINT `professor_curso_ibfk_1` FOREIGN KEY (`id_professor`) REFERENCES `professores` (`id`),
  ADD CONSTRAINT `professor_curso_ibfk_2` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`);

--
-- Limitadores para a tabela `professor_disciplina`
--
ALTER TABLE `professor_disciplina`
  ADD CONSTRAINT `professor_disciplina_ibfk_1` FOREIGN KEY (`id_professor`) REFERENCES `professores` (`id`),
  ADD CONSTRAINT `professor_disciplina_ibfk_2` FOREIGN KEY (`id_disciplina`) REFERENCES `disciplinas` (`id`);

--
-- Limitadores para a tabela `professor_turma`
--
ALTER TABLE `professor_turma`
  ADD CONSTRAINT `professor_turma_ibfk_1` FOREIGN KEY (`id_professor`) REFERENCES `professores` (`id`),
  ADD CONSTRAINT `professor_turma_ibfk_2` FOREIGN KEY (`id_turma`) REFERENCES `turmas` (`id`);

--
-- Limitadores para a tabela `turmas`
--
ALTER TABLE `turmas`
  ADD CONSTRAINT `turmas_ibfk_1` FOREIGN KEY (`id_curso`) REFERENCES `cursos` (`id`),
  ADD CONSTRAINT `turmas_ibfk_2` FOREIGN KEY (`id_classe`) REFERENCES `classes` (`id`);

--
-- Limitadores para a tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_tipo_usuario`) REFERENCES `tipo_usuario` (`id`),
  ADD CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`id_aluno`) REFERENCES `alunos` (`id`),
  ADD CONSTRAINT `usuarios_ibfk_3` FOREIGN KEY (`id_professor`) REFERENCES `professores` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
