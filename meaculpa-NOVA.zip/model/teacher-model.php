<?php
require_once __DIR__ . "/../config/config.php";
header("content-type: application/json");
class Teacher
{
    public static function listStudents($id)
    {
        global $con;
        $query = $con->prepare("SELECT alunos.id,alunos.nome,cursos.nome as curso,
            turmas.nome as turma,classes.numero as classe from professores 
            join professor_turma on professores.id=professor_turma.id_professor 
            join turmas on turmas.id=professor_turma.id_turma 
            join alunos on alunos.id_turma=turmas.id 
            join classes on classes.id=alunos.id_classe
            join cursos on alunos.id_curso=cursos.id
            join professor_disciplina on professores.id=professor_disciplina.id_professor
            join disciplinas on disciplinas.id=professor_disciplina.id_disciplina
            where professores.id=?");
        $query->execute([$id]);

        $students = $query->fetchAll(PDO::FETCH_ASSOC);

        foreach ($students as $s_index => $student) {
            $query = $con->prepare("SELECT disciplinas.nome from disciplina_classe 
                join disciplinas on disciplinas.id=disciplina_classe.id_disciplina 
                join classes on classes.id=disciplina_classe.id_classe 
                join alunos on alunos.id_classe=classes.id 
                where alunos.id=?");
            $query->execute([$students[$s_index]["id"]]);
            $students[$s_index]["disciplinas"] = $query->fetchAll(PDO::FETCH_ASSOC);
        }

        return $students;
    }
    public static function setStudentScore($studentId, $scoreId, $subjectId, $testId)
    {
        global $con;
        //validações
        $evalCheck = $con->prepare("SELECT avaliacao.id from aluno_avaliacao 
            join alunos on alunos.id=aluno_avaliacao.id_aluno
            join avaliacao on avaliacao.id=aluno_avaliacao.id_avaliacao
            where avaliacao.id_tipo_teste=? and avaliacao.id_disciplina=? and alunos.id=?");
        $evalCheck->execute([$testId, $subjectId, $studentId]);
        if ($evalCheck->fetchColumn())
            return ["status" => false, "msg" => "Já existe uma nota para esse teste, deseja atualizá-la?"];


        $query = $con->prepare("INSERT into avaliacao (id_nota,id_tipo_teste,id_disciplina) values (?,?,?)");
        $query->execute([$scoreId, $testId, $subjectId]);
        if (!$query)
            return [];
        $evaluationId = $con->prepare("SELECT id from avaliacao 
            where id_nota=? 
            and id_tipo_teste=? 
            and id_disciplina=?
            order by id desc limit 1");
        $evaluationId->execute([$scoreId, $testId, $subjectId]);
        if (!$evaluationId)
            return ["status" => false, "msg" => "Ocorreu um erro"];

        $evaluationId = $evaluationId->fetchColumn();

        $query = $con->prepare("INSERT into aluno_avaliacao (id_aluno,id_avaliacao) values (?,?)");
        $query->execute([$studentId, $evaluationId]);
        if (!$query)
            return ["status" => false, "msg" => "Ocorreu um erro"];
        return ["status" => true, "msg" => "Nota salva com sucesso"];
    }
    public static function updateStudentScore($studentId, $scoreId, $subjectId, $testId)
    {
        global $con;

        //validações
        $evalCheck = $con->prepare("SELECT avaliacao.id from aluno_avaliacao 
            join alunos on alunos.id=aluno_avaliacao.id_aluno
            join avaliacao on avaliacao.id=aluno_avaliacao.id_avaliacao
            where avaliacao.id_tipo_teste=? and avaliacao.id_disciplina=? and alunos.id=?");
        $evalCheck->execute([$testId, $subjectId, $studentId]);
        if (!$evalCheck->fetchColumn())
            return ["status" => false, "msg" => "Nota não definida ainda. Deseja publicar?"];

        $query = $con->prepare("UPDATE avaliacao 
            join aluno_avaliacao on aluno_avaliacao.id_avaliacao=avaliacao.id
            join alunos on alunos.id=aluno_avaliacao.id_aluno set avaliacao.id_nota=?
            where avaliacao.id_tipo_teste=? and avaliacao.id_disciplina=? and alunos.id=?");
        $query->execute([$scoreId, $testId, $subjectId, $studentId]);
        if (!$query)
            return ["status" => false, "msg" => "Não foi possível atualizar a nota"];
        return ["status" => true, "msg" => "Nota atualizada com sucesso"];
    }
    public static function setStudentPresence($studentId, $subjectId, $date, $dayofweek, $state, $teacherId)
    {
        global $con;

        //validações
        $preCheck = $con->prepare("SELECT presencas.id from presencas 
            join presenca_aluno on presencas.id=presenca_aluno.id_presenca 
            join alunos on alunos.id=presenca_aluno.id_aluno 
            where presencas.id_disciplina=? and presencas.data=? and alunos.id=?");
        $preCheck->execute([$subjectId, $date, $studentId]);
        if ($preCheck->fetchColumn())
            return ["status" => false, "msg" => "Já foi marcada presença para esse dia"];

        $canSave = $con->prepare("SELECT 1 from dias_disciplina 
            join professor_disciplina on professor_disciplina.id_disciplina=dias_disciplina.id_disciplina 
            where professor_disciplina.id_professor=? 
            and dias_disciplina.id_disciplina=? 
            and dias_disciplina.id_dia_aula=?");

        $canSave->execute([$teacherId, $subjectId, $dayofweek]);
        $canSave = $canSave->fetchColumn();
        if (!$canSave)
            return ["success" => false, "msg" => "Não pode marcar presença para este dia"];

        try {
            $query = $con->prepare("INSERT into presencas (estado,id_disciplina,data) values (?,?,?)");
            $query->execute([$state, $subjectId, $date]);

            $presenceId = $con->prepare("SELECT id from presencas 
                where id_disciplina=? 
                and estado=? 
                and data=? order by id desc limit 1");
            $presenceId->execute([$subjectId, $state, $date]);
            $presenceId = $presenceId->fetchColumn();

            $query = $con->prepare("INSERT into presenca_aluno (id_aluno,id_presenca) values (?,?)");
            $query->execute([$studentId, $presenceId]);

            return ["status" => true, "msg" => "Presença registada com sucesso"];
        } catch (Exception $ex) {
            return ["status" => false, "msg" => "Não foi possível marcar presença"];
        }
    }
    public static function listStudentMarkOptions($studentId)
    {
        global $con;
        $query = $con->prepare("SELECT * from notas");
        $query->execute();
        $marks = $query->fetchAll(PDO::FETCH_ASSOC);

        $query = $con->prepare("SELECT * from tipo_teste");
        $query->execute();
        $tests = $query->fetchAll(PDO::FETCH_ASSOC);

        $query = $con->prepare("SELECT disciplinas.id,disciplinas.nome as disciplina from 
            disciplina_curso 
            join cursos on cursos.id=disciplina_curso.id_curso 
            join disciplinas on disciplinas.id=disciplina_curso.id_disciplina 
            join alunos on cursos.id=alunos.id_curso 
            where alunos.id=?");
        $query->execute([$studentId]);
        $subjects = $query->fetchAll(PDO::FETCH_ASSOC);

        return ["disciplinas" => $subjects, "notas" => $marks, "testes" => $tests];
    }
}