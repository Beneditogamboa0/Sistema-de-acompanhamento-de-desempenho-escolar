<link rel="stylesheet" href="/meaculpa/public/fonts/fontawesome/css/all.min.css">
<link rel="stylesheet" href="/meaculpa/public/css/global/site.css">
<link rel="stylesheet" href="/meaculpa/public/css/global/vars.css">
<link rel="stylesheet" href="/meaculpa/public/css/global/media.css">
<link rel="stylesheet" href="/meaculpa/public/css/global/animations.css">
<link rel="stylesheet" href="/meaculpa/components/sidebar/sidebar.css">
<link rel="stylesheet" href="/meaculpa/components/header/header.css">
<link rel="stylesheet" href="/meaculpa/components/add-new-btn/add-new-btn.css">
<link rel="stylesheet" href="/meaculpa/components/modal/modal.css">
<link rel="stylesheet" href="/meaculpa/components/message-box/message-box.css">
<link rel="stylesheet" href="/meaculpa/components/user-list/user-list.css">
<link rel="shortcut icon" href="/meaculpa/public/images/logo.png" type="image/x-icon">