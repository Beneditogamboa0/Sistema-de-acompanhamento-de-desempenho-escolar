<nav>
    <ul>
        <?php
        switch ($_SESSION["type"]) {
            case "Aluno":
                require_once __DIR__ . "/../student-links/links.php";
                break;
            case "Admin":
                require_once __DIR__ . "/../admin-links/links.php";
                break;
            case "Professor":
                require_once __DIR__ . "/../teacher-links/links.php";
                break;
        }
        ?>
    </ul>
</nav>