<a href="/meaculpa/pages/student/info/index.php" class="link">
    <li><i class="fa fa-user"></i>Informações</li>
</a>
<a href="/meaculpa/pages/student/score/index.php" class="link">
    <li><i class="fa fa-0"></i>Notas</li>
</a>
<a href="/meaculpa/pages/student/presence/index.php" class="link">
    <li><i class="fa fa-thumbs-up"></i>Presenças</li>
</a>