<a href="/meaculpa/pages/admin/dashboard/index.php" class="link">
    <li><i class="fa fa-chart-simple"></i>Dashboard</li>
</a>
<a href="/meaculpa/pages/admin/students/index.php" class="link">
    <li><i class="fa fa-user"></i>Alunos</li>
</a>
<a href="/meaculpa/pages/admin/teachers/index.php" class="link">
    <li><i class="fa fa-graduation-cap"></i>Professores</li>
</a>