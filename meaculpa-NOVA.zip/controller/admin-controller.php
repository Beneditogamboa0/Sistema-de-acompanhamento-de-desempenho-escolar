<?php
require_once __DIR__ . "/../model/admin-model.php";
$adm = new Admin();
$op = json_decode(file_get_contents("php://input"), true);

function listStudents()
{
    global $adm;
    echo json_encode($adm->listAllStudents());
}
function listStudentInfo()
{
    global $op;
    echo json_encode(Admin::listStudentInformation($op["studentId"]));
}
function listTeachers()
{
    global $adm;
    echo json_encode($adm->listAllTeachers());
}
function listTeacherInfo()
{
    global $op;
    echo json_encode(Admin::listTeacherInformation($op["teacherId"]));
}
function listCourses()
{
    global $adm;
    echo json_encode($adm->listCourses());
}
function listGrades()
{
    global $adm;
    echo json_encode($adm->listGrades());
}
function listStudentMarks()
{
    global $op;
    echo json_encode(Admin::listStudentMarks($op["studentId"]));
}
function listStudentPresences()
{
    global $op;
    echo json_encode(Admin::listStudentPresences($op["studentId"]));
}
function registerStudent()
{
    global $op;
    echo json_encode(Admin::registerStudent(
        $op["name"],
        $op["birthdate"],
        $op["bi"],
        $op["parent"],
        $op["parentBi"],
        $op["phone"],
        $op["email"],
        $op["grade"],
        $op["course"],
        $op["class"],
        $op["secondPhone"]
    ));
}
function registerTeacher()
{
    global $op;
    echo json_encode(Admin::registerTeacher(
        $op["name"],
        $op["birthdate"],
        $op["bi"],
        $op["grades"],
        $op["courses"],
        $op["subjects"],
        $op["classes"]
    ));
}
function getRegisterOptions()
{
    global $adm;
    echo json_encode([
        "classes" => $adm->getGrades(),
        "cursos" => $adm->getCourses(),
        "turmas" => $adm->getClasses(),
        "disciplinas" => $adm->getSubjects()
    ]);
}
function generalStats()
{
    global $adm;
    echo json_encode($adm->getGeneralStats());
}