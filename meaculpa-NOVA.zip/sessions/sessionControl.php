<?php
session_start();
$userId = $_SESSION["id"] ?? null;
$currentPage = $_SERVER["SCRIPT_NAME"];
$loginPage = "/meaculpa/pages/login/index.php";
$signupPage = "/meaculpa/pages/signup/index.php";

if (!$userId && ($currentPage != $loginPage && $currentPage != $signupPage))
    header("Location: /meaculpa/pages/login/index.php");
else if ($userId && ($currentPage == $loginPage || $currentPage == $signupPage))
    header("Location: /meaculpa/pages/main/index.php");