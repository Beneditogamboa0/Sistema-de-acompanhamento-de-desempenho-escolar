<?php
session_start();
require_once "../controller/teacher-controller.php";

$op = $_GET["s"];
switch ($op) {
    case "students":
        getStudents();
        break;
    case "marks":
        listSetOptions();
        break;
    case "setMarks":
        setStudentMark();
        break;
    case "updateMarks":
        updateStudentMark();
        break;
    case "presences":
        listSetOptions();
        break;
    case "setPresence":
        setStudentPresence();
        break;
    case "info":
        teacherInfo();
        break;
}