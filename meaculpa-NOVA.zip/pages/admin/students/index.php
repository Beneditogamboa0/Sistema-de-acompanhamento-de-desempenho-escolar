<!--Topo do documento: Importar sempre-->
<?php require "../../../components/global/document-top.php" ?>

<!--Pôr sempre a main nas páginas-->
<!--
Estilos que dependem da página são referenciados acima da main
    e antes da importação
-->
<main>
    <?php require "../../../components/header/header.php" ?>
    <?php require "../../../components/user-list/user-list.php" ?>
</main>

<?php require "../../../components/global/document-bottom.php" ?>
<script src="/meaculpa/public/js/pages/admin/students.js"></script>
<!--Base do documento: Importar sempre-->