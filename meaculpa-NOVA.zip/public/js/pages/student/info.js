document.addEventListener("DOMContentLoaded", async () => {

    const ans=await fetch("/meaculpa/routes/studentRoutes.php?s=general")
    const general=await ans.json()
    console.log(general)

    const pizza = document.querySelector("#pizza")
    new Chart(pizza, {
        type: "pie",
        data: {
            labels: ["Média geral", `Melhor média: ${general.melhor.disciplina?general.melhor.disciplina:0}`, `Menor média: ${general.pior.disciplina?general.pior.disciplina:0}`],
            datasets: [{
                label: "Aproveitamento",
                data: [general.geral.media_geral??-1, general.melhor.media??0, general.pior.media??0],
                backgroundColor: ["purple", "blue", "red"],
                borderWidth: 1
            }]
        }
    })
    getInformation()
    getSubjects()
})

function writeSubjects(arr) {
    subjectContainer = document.querySelector(".s_list")
    subjectContainer.innerText = ""
    arr.forEach((s) => {
        subjectContainer.innerHTML += `
            <div>
                <span class="s_name">${s.nome}</span>
                ${s.dias.length > 0 ? s.dias.map(d => `${d.dia_aula}`).join(", ") : "Nenhum dia atribuído"}
            </div>
        `
    })
}
async function getSubjects() {
    ans = await fetch("/meaculpa/routes/studentRoutes.php?s=subjects")
    ans = await ans.json()
    writeSubjects(ans)
    console.log(ans)
}

function writeInformation(obj) {
    infoContainer = document.querySelector("div.info")
    infoContainer.innerHTML = `
        <div>
            <span>B</span>
            <span>Benedito</span>
        </div>
        <div>
            <span><strong>Número do BI:</strong> ${obj.bi}</span>
            <span><strong>Data de nascimento:</strong> ${obj.data_nascimento}</span>
            <span><strong>Classe:</strong> ${obj.classe}ª</span>
            <span><strong>Curso:</strong> ${obj.curso}</span>
            <span><strong>Turma:</strong> ${obj.turma}</span>
            <span><strong>Meu encarregado:</strong> ${obj.encarregado}</span>
            <span><strong>Seu BI:</strong> ${obj.bi_encarregado}</span>
            <span><strong>Seus Contactos:</strong> ${obj.email_encarregado} / ${obj.telefone}${obj.secundario ? ` / ${obj.secundario}` : ""}</span>
        </div>
    `
}
async function getInformation() {
    ans = await fetch("/meaculpa/routes/studentRoutes.php?s=info")
    ans = await ans.json()
    writeInformation(ans)
    console.log(ans)
}