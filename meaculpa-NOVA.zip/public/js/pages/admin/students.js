var s = 0
var classesBackup = null
const date = new Date()
function writeStudents(arr) {
    studentsContainer = document.querySelector(".user-container")
    studentsContainer.innerText = ""
    if (arr.length == 0){
        studentsContainer.style.display="flex"
        studentsContainer.style.alignItems="center"
        studentsContainer.style.justifyContent="center"
        studentsContainer.innerHTML = "<span style=font-size:var(--fonte-xl)>Nenhum aluno registado</span>"
    }
    arr.forEach((s) => {
        studentsContainer.innerHTML += `
            <div class="user">
            <span>Nome: ${s.nome}</span>
            <span>Classe: ${s.classe}ª</span>
            <span>Curso: ${s.curso}</span>
            <span>Turma: ${s.turma}</span>
            <div class="buttons">
                <button onclick="getStudentInfo(event);toggleModal()" value=${s.id}>Informações</button>
                <button onclick="getStudentMarks(event);toggleModal()" value=${s.id}>Notas</button>
                <button onclick="getStudentPresences(event);toggleModal()" value=${s.id}>Presenças</button>
            </div>
            </div>
        `
    })
}
async function getStudents() {
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=students")
    ans = await ans.json()
    console.log(ans)
    writeStudents(ans)
}
document.addEventListener("DOMContentLoaded", getStudents)

function writeStudentInfo(obj) {
    modalArea = document.querySelector(".modal-area")

    modalArea.innerHTML = `
        <div class="user-info">
            <div>
                <span class="initial">${obj.nome[0]}</span>
                <span>${obj.nome}</span>
            </div>
            <span><strong>Número do BI:</strong> ${obj.bi}</span>
            <span><strong>Data de nascimento:</strong> ${obj.data_nascimento.split("-").reverse().join("-")} (${date.getFullYear() - obj.data_nascimento.slice(0, obj.data_nascimento.indexOf("-"))} Anos)</span>
            <span><strong>Classe:</strong> ${obj.classe}</span>
            <span><strong>Curso:</strong> ${obj.curso}</span>
            <span><strong>Turma:</strong> ${obj.turma}</span>
            <span><strong>Encarregado:</strong> ${obj.encarregado}</span>
            <span><strong>BI do encarregado:</strong> ${obj.bi_encarregado}</span>
            <span><strong>Contactos:</strong> ${obj.email_encarregado} / ${obj.telefone_encarregado}${obj.telefone_secundario ? ` / ${obj.telefone_secundario}` : ""}</span>
        </div>
    `
}
async function getStudentInfo(btn) {
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=studentInfo", {
        method: "POST",
        body: JSON.stringify({ studentId: btn.target.value })
    })
    ans = await ans.json()
    console.log(ans)
    writeStudentInfo(ans)
}

function writeStudentMarks(arr) {
    modalArea = document.querySelector(".modal-area")
    modalArea.innerText = ""
    if (arr.length == 0)
        modalArea.innerHTML = "<span>Nenhuma nota atribuída</span>"
    arr.forEach((s) => {
        modalArea.innerHTML += `
            <span>${s.disciplina} (${s.teste}): <span style="color:${s.nota <= 9 ? "red" : "green"}">${s.nota} valores</span></span>
        `
    })
}

function writeStudentPresences(arr) {
    modalArea = document.querySelector(".modal-area")
    modalArea.innerText = ""
    if (arr.length == 0)
        modalArea.innerHTML = "<span>Nenhuma presença registada</span>"
    arr.forEach((p) => {
        modalArea.innerHTML += `
            <span style="font-size: 1rem;">${p.nome} (${p.data.split("-").reverse().join("/")}): ${p.estado ? "Presente" : "Ausente"}</span>
        `
    })
}

async function getStudentPresences(btn) {
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=studentPresences", {
        method: "POST",
        body: JSON.stringify({ studentId: btn.target.value })
    })
    ans = await ans.json()
    console.log(ans)
    writeStudentPresences(ans)
}
async function getStudentMarks(btn) {
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=studentMarks", {
        method: "POST",
        body: JSON.stringify({ studentId: btn.target.value })
    })
    ans = await ans.json()
    console.log(ans)
    writeStudentMarks(ans)
}

async function registerForm() {
    modalArea = document.querySelector(".modal-area")
    modalArea.innerHTML = `
        <div class="form">
            <span>Novo Aluno</span>
            <form onsubmit='return registerStudent()'>
                <div class="zone">
                    <label for="nome">Nome</label>
                    <input id="nome" type="text">
                    <label for="bi">BI</label>
                    <input id="bi" type="text">
                    <label for="nascimento">Data de Nascimento</label>
                    <input id="nascimento" type="date" min="${date.getFullYear()-15}-01-01">
                </div>
                <div class="zone">
                    <label for="enome">Nome do encarregado</label>
                    <input id="enome" type="text">
                    <label for="ebi">BI do encarregado</label>
                    <input id="ebi" type="text" minlength="14" maxlength="14">
                    <label for="eemail">Email do encarregado</label>
                    <input id="eemail" type="email">
                    <label for="etelefone">Telefone do encarregado</label>
                    <input id="etelefone" type="number" min="9" minlength="9" maxlength="9">
                    <label for="esecundario">Telefone secundário</label>
                    <input id="esecundario" type="number" min="9" maxlength="9">
                </div>
                <div class="zone">
                    <label for="classe">Classe</label>
                    <select id="classe">
                    <option value="">Selecione um(a)</option>
                    </select>
                </div>
                <div class="zone">
                    <label for="curso">Curso</label>
                    <select id="curso">
                    <option value="">Selecione um(a)</option>
                    </select>
                </div>
                <div class="zone">
                    <label for="turma">Turma</label>
                    <select id="turma">
                    <option value="">Selecione um(a)</option>
                    </select>
                </div>
                <div class="buttons formButtons">
                    <button onclick=previous() id="prevForm" type="button">Voltar</button>
                    <button type="submit">Salvar</button>
                    <button onclick=next() id="nextForm" type="button">Avançar</button>
                </div>
            </form>
        </div>
    `

    obj = await fetch("/meaculpa/routes/adminRoutes.php?s=registerOptions")
    obj = await obj.json()

    //escrever classes, cursos e turmas
    obj.classes.forEach((g) => {
        classe.innerHTML += `<option value=${g.id}>${g.numero}</option>`
    })
    obj.cursos.forEach((c) => {
        curso.innerHTML += `<option value=${c.id}>${c.nome}</option>`
    })
    obj.turmas.forEach((t) => {
        turma.innerHTML += `<option value=${t.id}>${t.nome}</option>`
    })
}

async function registerStudent() {
    event.preventDefault()
    const student = {
        name: nome.value,
        bi: bi.value.toUpperCase(),
        birthdate: nascimento.value,
        parentBi: ebi.value.toUpperCase(),
        parent: enome.value,
        phone: etelefone.value,
        secondPhone: esecundario.value,
        email: eemail.value,
        grade: classe.value,
        course: curso.value,
        class: turma.value
    }
    for (var atr in student) {
        if ((student[atr] == "" || student[atr] == null) && atr!="secondPhone") {
            showMessage("Preencha todos os campos", "orange","warning")
            return
        }
    }
    ans = await fetch("/meaculpa/routes/adminRoutes.php?s=registerStudent", {
        method: "POST",
        body: JSON.stringify(student)
    })
    ans = await ans.json()
    console.log(ans)
    if (!ans.status) {
        showMessage(ans.msg, "red","warning")
        return
    }
    showMessage(ans.msg, "green","check")
    setTimeout(() => window.location.href = "", waitTime)
}

function checkEmptyInputs(inputs) {
    inputs.forEach((i) => {
        if (i.value == "" || i.value == null)
            return true
    })
    return false
}

function filterClass() {
    turma = [...document.getElementById("turma").options]
    if (classesBackup == null)
        classesBackup = turma
    iturma.innerText = ""
    grade = iclasse.selectedOptions[0].innerText
    course = icurso.selectedOptions[0].innerText
    course = course.slice(course.indexOf("(") + 1, course.lastIndexOf(")"))

    filtered = turma.filter(t => t.innerText.includes(grade) && t.innerText.includes(course))

    if (filtered.length == 0)
        turma.innerHTML = "<option value=''>Sem turmas existentes</option>"
    filtered.forEach((op) => {
        turma.innerHTML += `<option value="${op.value}">${op.innerText ? op.innerText : "Sem turmas"}</option>`
    })
}