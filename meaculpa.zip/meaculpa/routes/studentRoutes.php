<?php
session_start();
require_once "../controller/student-controller.php";

$option = $_GET["s"];
switch ($option) {
    case "info":
        getStudentInfo();
        break;
    case "marks":
        getStudentMarks();
        break;
    case "subjects":
        getStudentSubjects();
        break;
    case "presences":
        getStudentPresences();
        break;
    case "general":
        getStudentGeneralInfo();
        break;
}
