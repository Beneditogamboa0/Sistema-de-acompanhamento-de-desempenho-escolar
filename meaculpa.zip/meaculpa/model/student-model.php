<?php
include_once __DIR__ . ("/../config/config.php");
header("content-type:application/json");
class Student
{
    public static function getStudentInfo($id)
    {
        global $con;
        $student = $con->prepare("SELECT alunos.id,alunos.nome,alunos.data_nascimento,
        alunos.bi,
        classes.numero as classe,
        turmas.nome as turma,
        cursos.nome as curso,
        encarregados.nome as encarregado,encarregados.bi as bi_encarregado,contacto_encarregado.telefone as telefone,
        contacto_encarregado.telefone_secundario as secundario,contacto_encarregado.email as email_encarregado 
        from alunos
        join encarregados on alunos.id_encarregado=encarregados.id 
        join contacto_encarregado on encarregados.id=contacto_encarregado.id_encarregado
        join cursos on alunos.id_curso=cursos.id
        join turmas on turmas.id=alunos.id_turma
        join classes on classes.id=alunos.id_classe where alunos.id=?");
        $student->execute([$id]);
        return $student->fetch(PDO::FETCH_ASSOC);
    }
    public static function getSubjects($id)
    {
        global $con;
        $query = $con->prepare("SELECT disciplinas.nome from disciplina_curso 
        join cursos on disciplina_curso.id_curso=cursos.id 
        join disciplinas on disciplinas.id=disciplina_curso.id_disciplina 
        join alunos on alunos.id_curso=cursos.id 
        where alunos.id=?");
        $query->execute([$id]);
        $subjects = $query->fetchAll(PDO::FETCH_ASSOC);
        foreach ($subjects as $s_index => $subject) {
            $query = $con->prepare("SELECT dias_aula.dia as dia_aula from dias_disciplina 
            join turmas on turmas.id=dias_disciplina.id_turma 
            join disciplinas on disciplinas.id=dias_disciplina.id_disciplina 
            join dias_aula on dias_aula.id=dias_disciplina.id_dia_aula 
            join alunos on alunos.id_turma=turmas.id 
            where alunos.id=? and disciplinas.nome=?");
            $query->execute([$id, $subjects[$s_index]["nome"]]);
            $subjects[$s_index]["dias"] = $query->fetchAll(PDO::FETCH_ASSOC);
        }
        return $subjects;
    }
    public static function getTestsMarks($id)
    {
        global $con;
        $query = $con->prepare("SELECT disciplinas.nome from disciplina_classe 
        join disciplinas on disciplinas.id=disciplina_classe.id_disciplina 
        join classes on classes.id=disciplina_classe.id_classe 
        join alunos on classes.id=alunos.id_classe 
        where alunos.id=?");
        $query->execute([$id]);
        $subjects = $query->fetchAll(PDO::FETCH_ASSOC);
        foreach ($subjects as $s_index => $subject) {
            $query = $con->prepare("SELECT tipo_teste.nome as teste,notas.nota from aluno_avaliacao 
            join avaliacao on avaliacao.id=aluno_avaliacao.id_avaliacao 
            join disciplinas on disciplinas.id=avaliacao.id_disciplina join alunos on alunos.id=aluno_avaliacao.id_aluno 
            join tipo_teste on tipo_teste.id=avaliacao.id_tipo_teste join notas on notas.id=avaliacao.id_nota 
            where alunos.id=? and disciplinas.nome=?;");
            $query->execute([$id, $subjects[$s_index]["nome"]]);
            $subjects[$s_index]["testes"] = $query->fetchAll(PDO::FETCH_ASSOC);
        }
        return $subjects;
    }

    public static function getPresences($id)
    {
        global $con;
        $query = $con->prepare("SELECT disciplinas.nome as disciplina from presenca_aluno 
        join presencas on presencas.id=presenca_aluno.id_presenca 
        join disciplinas on disciplinas.id=presencas.id_disciplina 
        join alunos on alunos.id=presenca_aluno.id_aluno 
        where alunos.id=?");
        $query->execute([$id]);
        $subjects = $query->fetchAll(PDO::FETCH_ASSOC);
        foreach ($subjects as $s_index => $subject) {
            //Total de presenças
            $query = $con->prepare("SELECT count(id_presenca) from presenca_aluno
            join alunos on alunos.id=presenca_aluno.id_aluno
            join presencas on presencas.id=presenca_aluno.id_presenca
            join disciplinas on disciplinas.id=presencas.id_disciplina
            where disciplinas.nome=? and alunos.id=?");
            $query->execute([$subjects[$s_index]["disciplina"], $id]);
            $subjects[$s_index]["total_presencas"] = $query->fetchColumn();

            //total de faltas
            $query = $con->prepare("SELECT count(id_presenca) from presenca_aluno 
            join presencas on presencas.id=presenca_aluno.id_presenca 
            join disciplinas on disciplinas.id=presencas.id_disciplina 
            join alunos on alunos.id=presenca_aluno.id_aluno 
            where disciplinas.nome=? and alunos.id=? and presencas.estado=0");
            $query->execute([$subjects[$s_index]["disciplina"], $id]);
            $subjects[$s_index]["faltas"] = $query->fetchColumn();

            //total de 'apareceu'
            $query = $con->prepare("SELECT count(id_presenca) from presenca_aluno 
            join presencas on presencas.id=presenca_aluno.id_presenca 
            join disciplinas on disciplinas.id=presencas.id_disciplina 
            join alunos on alunos.id=presenca_aluno.id_aluno 
            where disciplinas.nome=? and alunos.id=? and presencas.estado=1");
            $query->execute([$subjects[$s_index]["disciplina"], $id]);
            $subjects[$s_index]["presencas"] = $query->fetchColumn();
        }
        return $subjects;
    }
    public static function getGeneralInfo($id)
    {
        global $con;
        $best = $con->prepare("SELECT 
    d.id AS id_disciplina,
    d.nome AS disciplina,
    AVG(n.nota) AS media
FROM aluno_avaliacao aa
JOIN avaliacao a ON a.id = aa.id_avaliacao
JOIN notas n ON n.id = a.id_nota
JOIN disciplinas d ON d.id = a.id_disciplina
WHERE aa.id_aluno = ?
GROUP BY d.id
ORDER BY media DESC
LIMIT 1;
");
        $best->execute([$id]);
        $best = $best->fetch(PDO::FETCH_ASSOC);

        $worst = $con->prepare("SELECT 
    d.id AS id_disciplina,
    d.nome AS disciplina,
    AVG(n.nota) AS media
FROM aluno_avaliacao aa
JOIN avaliacao a ON a.id = aa.id_avaliacao
JOIN notas n ON n.id = a.id_nota
JOIN disciplinas d ON d.id = a.id_disciplina
WHERE aa.id_aluno = ?
GROUP BY d.id
ORDER BY media ASC
LIMIT 1;
");
        $worst->execute([$id]);
        $worst = $worst->fetch(PDO::FETCH_ASSOC);

        $general = $con->prepare("SELECT AVG(n.nota) AS media_geral
FROM aluno_avaliacao aa
JOIN avaliacao a ON a.id = aa.id_avaliacao
JOIN notas n ON n.id = a.id_nota
WHERE aa.id_aluno = ?;
");
        $general->execute([$id]);
        $general = $general->fetch(PDO::FETCH_ASSOC);

        return ["melhor"=>$best,"pior"=>$worst,"geral"=>$general];
    }
}
/*
select disciplinas.nome from disciplina_classe join disciplinas on disciplinas.id=disciplina_classe.id_disciplina 
join classes on classes.id=disciplina_classe.id_classe join alunos on classes.id=alunos.id_classe where alunos.id=1;

select tipo_teste.nome as teste,notas.nota from aluno_avaliacao join avaliacao on avaliacao.id=aluno_avaliacao.id_avaliacao 
join disciplinas on disciplinas.id=avaliacao.id_disciplina join alunos on alunos.id=aluno_avaliacao.id_aluno 
join tipo_teste on tipo_teste.id=avaliacao.id_tipo_teste join notas on notas.id=avaliacao.id_nota 
where alunos.id=1 and disciplinas.nome='Matemática';
*/