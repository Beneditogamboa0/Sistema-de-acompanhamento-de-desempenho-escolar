<?php
include_once __DIR__ . ("/../config/config.php");
class User
{
    private $name, $bi, $password, $userType;
    public function __construct($bi, $password, $userType = null)
    {
        $this->bi = $bi;
        $this->password = $password;
        $this->userType = $userType;
    }
    public function signUp()
    {
        global $con;

        switch ($this->userType) {
            case 1:
                $teacherId = $con->prepare("SELECT id from professores where bi=?");
                $teacherId->execute([$this->bi]);
                $teacherId = $teacherId->fetchColumn();

                $query = $con->prepare("INSERT into usuarios (senha,id_tipo_usuario,id_professor) values (?,?,?)");
                $query->execute([$this->password, $this->userType, $teacherId]);
                if (!$query)
                    return ["status" => false, "msg" => "Ocorreu algum erro"];
                return ["status" => true, "msg" => "Registro feito com sucesso"];
            case 2:
                $studentId = $con->prepare("SELECT id from alunos where bi=?");
                $studentId->execute([$this->bi]);
                $studentId = $studentId->fetchColumn();

                $query = $con->prepare("INSERT into usuarios (senha,id_tipo_usuario,id_aluno) values (?,?,?)");
                $query->execute([$this->password, $this->userType, $studentId]);
                if (!$query)
                    return ["status" => false, "msg" => "Ocorreu algum erro"];
                return ["status" => true, "msg" => "Registro feito com sucesso"];
        }
    }
    public static function login($bi, $password)
    {
        global $con;
        $userVerify = null;

        $studentBi = $con->prepare("select id from alunos where bi=?");
        $studentBi->execute([$bi]);
        $studentBi = $studentBi->fetchColumn();

        $teacherBi = $con->prepare("select id from professores where bi=?");
        $teacherBi->execute([$bi]);
        $teacherBi = $teacherBi->fetchColumn();

        if ($studentBi) {
            $query = $con->prepare("SELECT usuarios.senha, alunos.bi from usuarios join alunos on alunos.id=id_aluno where usuarios.id_aluno=?");
            $query->execute([$studentBi]);
            $userVerify = $query->fetch(PDO::FETCH_ASSOC);
            if(!$userVerify)
                return ["status"=>false,"msg"=>"NIF ou senha incorretos"];
        } else if($teacherBi){
            $query = $con->prepare("SELECT usuarios.senha, professores.bi from usuarios join professores on professores.id=id_professor where usuarios.id_professor=?");
            $query->execute([$teacherBi]);
            $userVerify = $query->fetch(PDO::FETCH_ASSOC);
            if(!$userVerify)
                return ["status"=>false,"msg"=>"NIF ou senha incorretos"];
        }
        else{
            $query=$con->prepare("SELECT nif as bi,senha from admin where nif=?");
            $query->execute([$bi]);
            $userVerify=$query->fetch(PDO::FETCH_ASSOC);
            if(!$userVerify)
                return ["status"=>false,"msg"=>"NIF ou senha incorretos"];
        }
        
        if ($bi != $userVerify["bi"] || $password != $userVerify["senha"]) {
            return ["status" => false, "msg" => "NIF ou senha incorretos"];
        }

        if ($studentBi) {
            $query = $con->prepare("SELECT alunos.id as id, alunos.nome,tipo_usuario.tipo as tipo_usuario from usuarios join tipo_usuario on id_tipo_usuario=tipo_usuario.id join alunos on alunos.id=id_aluno where usuarios.senha=?");
            $query->execute([$password]);
        } else if($teacherBi){
            $query = $con->prepare("SELECT professores.id as id, professores.nome,tipo_usuario.tipo as tipo_usuario from usuarios join tipo_usuario on id_tipo_usuario=tipo_usuario.id join professores on professores.id=id_professor where usuarios.senha=?");
            $query->execute([$password]);
        }
        else{
            $query=$con->prepare("SELECT id,tipo_usuario,nome from admin where senha=?");
            $query->execute([$password]);
        }
        //primeiro pegar a senha e o email, depois comparar com as que foram enviadas e se não coincidirem o status passa para "false"
        return ["status" => true, "msg" => "Logado com sucesso", "user" => $query->fetch(PDO::FETCH_ASSOC)];
    }
}