<?php
require_once __DIR__ . "/../model/teacher-model.php";
require_once __DIR__ . "/../model/admin-model.php";
$student = json_decode(file_get_contents("php://input"), true);
function getStudents()
{
    echo json_encode(Teacher::listStudents($_SESSION["id"]));
}
function listSetOptions()
{
    global $student;
    echo json_encode(Teacher::listStudentMarkOptions($student["studentId"]));
}
function setStudentMark()
{
    global $student;
    echo json_encode(Teacher::setStudentScore(
        $student["id"],
        $student["mark"],
        $student["subject"],
        $student["test"]
    ));
}
function updateStudentMark()
{
    global $student;
    echo json_encode(Teacher::updateStudentScore(
        $student["id"],
        $student["mark"],
        $student["subject"],
        $student["test"]
    ));
}
function setStudentPresence()
{
    global $student;
    echo json_encode(Teacher::setStudentPresence(
        $student["id"],
        $student["subject"],
        $student["date"],
        $student["state"]
    ));
}
function teacherInfo()
{
    echo json_encode(Admin::listTeacherInformation($_SESSION["id"]));
}