<?php
    include_once __DIR__ . ("/../model/student-model.php");
    function getStudentInfo(){
        echo json_encode(Student::getStudentInfo($_SESSION["id"]));
        die();
    }
    function getStudentMarks(){
        echo json_encode(Student::getTestsMarks($_SESSION["id"]));
        die();
    }
    function getStudentSubjects(){
        echo json_encode(Student::getSubjects($_SESSION["id"]));
    }
    function getStudentPresences(){
        echo json_encode(Student::getPresences($_SESSION["id"]));
    }
    function getStudentGeneralInfo(){
        echo json_encode(Student::getGeneralInfo($_SESSION["id"]));
    }