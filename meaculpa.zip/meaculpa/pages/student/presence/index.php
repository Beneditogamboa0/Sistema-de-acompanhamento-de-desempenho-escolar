<!--Topo do documento: Importar sempre-->
<?php require "../../../components/global/document-top.php" ?>

<!--Pôr sempre a main nas páginas-->
<!--
Estilos que dependem da página são referenciados acima da main
    e antes da importação
-->
<link rel="stylesheet" href="/meaculpa/public/css/pages/student/presence.css">
<main>
    <?php require "../../../components/header/header.php" ?>
    <div class="presences">
    </div>
</main>

<?php require "../../../components/global/document-bottom.php" ?>
<script src="/meaculpa/public/js/pages/student/presences.js"></script>
<!--Base do documento: Importar sempre-->