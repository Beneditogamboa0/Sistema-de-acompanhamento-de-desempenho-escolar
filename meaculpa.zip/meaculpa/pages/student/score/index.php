<!--Topo do documento: Importar sempre-->
<?php require "../../../components/global/document-top.php" ?>

<!--Pôr sempre a main nas páginas-->
<!--
Estilos que dependem da página são referenciados acima da main
    e antes da importação
-->
<link rel="stylesheet" href="/meaculpa/public/css/pages/student/score.css">
<main>
    <?php require "../../../components/header/header.php" ?>
    <div class="scores">
        <div class="subject">
            <span>Migos</span>
            <div class="s_scores">
            </div>
        </div>
    </div>
</main>

<?php require "../../../components/global/document-bottom.php" ?>
<script src="/meaculpa/public/js/pages/student/marks.js"></script>
<!--Base do documento: Importar sempre-->