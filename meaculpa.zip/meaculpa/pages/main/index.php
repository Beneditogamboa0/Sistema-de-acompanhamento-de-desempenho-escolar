<?php
    session_start();
    $type=$_SESSION["type"];
    switch($type){
        case "Aluno":
            header("Location: /meaculpa/pages/student/info/");
            break;
        case "Professor":
            header("Location: /meaculpa/pages/teacher/students/");
            break;
        case "Admin":
            header("Location: /meaculpa/pages/admin/dashboard/");
            break;
    }