function writeMarks(arr) {
    marksContainer = document.querySelector(".scores")
    marksContainer.innerText = ""
    if (arr.length == 0)
        marksContainer.innerHTML = "<span>Nenhuma nota publicada</span>"
    arr.forEach((m) => {
        marksContainer.innerHTML += `
            <div class="subject">
            <span>${m.nome}</span>
            <div class="s_scores">
            ${m.testes.length > 0 ?
                m.testes.map(t => `<div><span>${t.teste}</span><span style=background-color:${t.nota<=9?"red":"green"}>${t.nota}</span></div>`).join("") :
                "<span style=font-size:var(--fonte-md)>Nenhuma Nota publicada</span>"}
            </div>
        </div>
        `
    })
}
async function getMarks() {
    ans = await fetch("/meaculpa/routes/studentRoutes.php?s=marks")
    ans = await ans.json()
    console.log(ans)
    writeMarks(ans)
}
getMarks()