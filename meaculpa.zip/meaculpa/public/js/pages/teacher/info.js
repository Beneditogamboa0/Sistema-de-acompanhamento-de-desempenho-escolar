function writeTeacherInfo(obj) {
    infoContainer = document.querySelector(".information")

    grades = document.createElement("span")
    courses = document.createElement("span")
    turmas = document.createElement("span")
    disciplinas = document.createElement("span")

    grades.innerText = "Classe(s): "
    courses.innerText = "Curso(s): "
    turmas.innerText = "Turma(s): "
    disciplinas.innerText = "Turma(s): "

    obj.classes.forEach((atr) => {
        grades.innerText += `${atr.classe}ª, `
    })
    obj.cursos.forEach((atr) => {
        courses.innerText += `${atr.curso}, `
    })
    obj.disciplinas.forEach((atr) => {
        disciplinas.innerText += `${atr.disciplina}, `
    })
    obj.turmas.forEach((atr) => {
        turmas.innerText += `${atr.turma}, `
    })

    infoContainer.innerHTML = `
        <span>Nome: ${obj.nome}</span>
        <span>BI: ${obj.bi}</span>
        <span>Data de nascimento: ${obj.data_nascimento}</span>
    `
    grades.innerText = grades.innerText.slice(0, grades.innerText.lastIndexOf(","))
    courses.innerText = courses.innerText.slice(0, courses.innerText.lastIndexOf(","))
    turmas.innerText = turmas.innerText.slice(0, turmas.innerText.lastIndexOf(","))
    disciplinas.innerText = disciplinas.innerText.slice(0, disciplinas.innerText.lastIndexOf(","))
    
    infoContainer.appendChild(grades)
    infoContainer.appendChild(courses)
    infoContainer.appendChild(turmas)
    infoContainer.appendChild(disciplinas)
}
async function getTeacherInfo() {
    ans = await fetch("../../routes/teacherRoutes.php?s=info")
    ans = await ans.json()
    console.log(ans)
    writeTeacherInfo(ans)
}
document.addEventListener("DOMContentLoaded", getTeacherInfo)