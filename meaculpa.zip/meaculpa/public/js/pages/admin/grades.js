function writeGrades(arr){
    gradesList=document.querySelector(".grades-list")
    gradesList.innerText=""
    arr.forEach((g)=>{
        div=document.createElement("div")
        div.classList.add("grade")
        div.innerHTML=`
            <span>${g.classe}ª classe</span>
        `
        gradesList.appendChild(div)
    })
}
async function getGrades(){
    ans=await fetch("../../routes/adminRoutes.php?s=grades")
    ans=await ans.json()
    console.log(ans)
    writeGrades(ans)
}
getGrades()