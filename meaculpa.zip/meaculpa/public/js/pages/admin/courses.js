/*function writeCourses(arr){
    coursesList=document.querySelector(".courses-list")
    coursesList.innerText=""
    arr.forEach((g)=>{
        div=document.createElement("div")
        div.classList.add("course")
        div.innerHTML=`
            <span>${g.nome}</span>
        `
        coursesList.appendChild(div)
    })
}
async function getCourses(){
    ans=await fetch("../../routes/adminRoutes.php?s=courses")
    ans=await ans.json()
    console.log(ans)
    writeCourses(ans)
}
getCourses()
*/