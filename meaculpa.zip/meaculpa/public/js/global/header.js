const profilePic=document.querySelector("header .pfp")
function toggleLogout(){
    const logout=document.querySelector("header div.options")
    logout.classList.toggle("on")
}
profilePic.addEventListener("click",toggleLogout)