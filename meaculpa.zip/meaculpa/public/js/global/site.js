const waitTime=2500
const btnCloseModal=document.querySelector("div.modal button")
const logoutBtn=document.querySelector("div.options span.logout")

function toggleModal() {
    modal = document.querySelector(".modal")
    modal.classList.toggle("on")
}
btnCloseModal.addEventListener("click",toggleModal)

function showMessage(msg,color,icon){
    msgBox=document.querySelector("div.message-box")
    msgBox.classList.add("on")
    msgBox.style.backgroundColor=color
    msgBox.innerHTML=`
        <div>
            <i class="fa fa-${icon}"></i>
        </div>
        <span>${msg}</span>
    `
    setTimeout(()=>{
        msgBox.classList.remove("on")
    },waitTime)
}

async function logout() {
    ans = await fetch("/meaculpa/pages/destroy.php", {
        method: "post",
        body: true
    })
    ans = await ans.json()
    window.location.href = ans.redirect
    console.log("migos")
}

console.log(logoutBtn)
logoutBtn.addEventListener("click",logout)