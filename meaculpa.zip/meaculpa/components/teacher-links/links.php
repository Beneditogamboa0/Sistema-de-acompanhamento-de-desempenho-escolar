<a href="/meaculpa/pages/teacher/students/index.php" class="link">
    <li><i class="fa fa-graduation-cap"></i>Alunos</li>
</a>