<div class="user-container">
    <div class="user">
        <span>Nome: </span>
        <span>Classe: </span>
        <span>Curso: </span>
        <span>Turma: </span>
        <div class="buttons">
            <button value="1">Informações</button>
            <button value="1">Presenças</button>
            <button value="1">Notas</button>
        </div>
    </div>
</div>